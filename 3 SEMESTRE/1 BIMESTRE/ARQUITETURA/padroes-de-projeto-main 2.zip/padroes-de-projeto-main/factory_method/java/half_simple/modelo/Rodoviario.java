package factory_method.java.half_simple.modelo;

public class Rodoviario extends Transporte {

    public void entregar() { 
        
        System.out.println("Entregar com transporte Rodoviário");
    
    }  
}
