package factory_method.java.simple.modelo;

public class Hidroviario extends Transporte {

    public void entregar() { 
    
        System.out.println("Entregar com transporte hidroviário");

    }  
    
}
