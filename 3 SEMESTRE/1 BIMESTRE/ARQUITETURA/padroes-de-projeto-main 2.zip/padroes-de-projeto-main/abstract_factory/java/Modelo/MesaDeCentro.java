package abstract_factory.java.Modelo;

public interface MesaDeCentro {

    public void colocarDecoracao();

}
