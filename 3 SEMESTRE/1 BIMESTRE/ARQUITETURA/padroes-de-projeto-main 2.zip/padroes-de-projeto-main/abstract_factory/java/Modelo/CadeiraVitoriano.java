package abstract_factory.java.Modelo;

public class CadeiraVitoriano implements Cadeira {

    public void sentar() {
        System.out.println("Sentado em uma cadeira vitoriana");
    }
  
}
