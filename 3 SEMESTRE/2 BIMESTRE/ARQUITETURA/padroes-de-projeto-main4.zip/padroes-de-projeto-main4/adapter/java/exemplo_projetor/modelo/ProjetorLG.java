package adapter.java.exemplo_projetor.modelo;

public class ProjetorLG {

    public void enable(int timer) {
        System.out.println("Ligando projetor da LG em " + timer + " minutos");
      }
         
}