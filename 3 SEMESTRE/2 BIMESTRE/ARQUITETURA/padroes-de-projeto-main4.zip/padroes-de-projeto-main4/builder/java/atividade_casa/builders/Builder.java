package builder.java.atividade_casa.builders;


public interface Builder {

    //"Preciso que você implemente o meu código";

}
