package factory_method.java.exemplo_transportes.depois_do_padrao.modelo;

public abstract class Transporte {
    
    public abstract void entregar();
  
}
