package factory_method.java.exemplo_transportes.simple.modelo;

public class Rodoviario extends Transporte {

    public void entregar() { 
        
        System.out.println("Entregar com transporte Rodoviário");
    
    }  
}
