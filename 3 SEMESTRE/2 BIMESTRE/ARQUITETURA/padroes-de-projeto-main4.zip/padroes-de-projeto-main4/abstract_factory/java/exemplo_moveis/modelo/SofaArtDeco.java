package abstract_factory.java.exemplo_moveis.modelo;

public class SofaArtDeco implements Sofa {
    public void deitar(){
        System.out.println("Deitando em um sofa art deco");
    }
}
