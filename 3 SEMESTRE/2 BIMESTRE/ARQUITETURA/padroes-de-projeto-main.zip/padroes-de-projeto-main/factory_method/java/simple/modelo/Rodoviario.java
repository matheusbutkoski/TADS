package factory_method.java.simple.modelo;

public class Rodoviario extends Transporte {

    public void entregar() { 
        
        System.out.println("Entregar com transporte Rodoviário");
    
    }  
}
