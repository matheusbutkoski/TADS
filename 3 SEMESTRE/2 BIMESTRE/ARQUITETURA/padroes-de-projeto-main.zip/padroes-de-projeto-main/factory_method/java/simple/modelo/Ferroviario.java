package factory_method.java.simple.modelo;

public class Ferroviario extends Transporte {

    public void entregar() { 
    
        System.out.println("Entrega com transporte Ferroviário");

    }     
}
