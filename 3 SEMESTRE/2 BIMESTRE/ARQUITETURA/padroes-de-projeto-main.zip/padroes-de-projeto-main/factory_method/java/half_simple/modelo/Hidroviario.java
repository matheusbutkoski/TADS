package factory_method.java.half_simple.modelo;

public class Hidroviario extends Transporte {

    public void entregar() { 
    
        System.out.println("Entregar com transporte hidroviário");

    }  
    
}
