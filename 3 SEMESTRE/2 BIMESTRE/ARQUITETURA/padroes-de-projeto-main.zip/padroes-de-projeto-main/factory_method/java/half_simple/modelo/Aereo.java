package factory_method.java.half_simple.modelo;


public class Aereo extends Transporte {

    public void entregar() { 
    
        System.out.println("Entrega com transporte Aero");

    }    
    
}
