package facade.java.atividade_computador.facade;

public class ComputadorFacade {
     
    //implemente o que esta faltando 
   

    public void incializarComputador(){
        
        System.out.println("Inicializando computador...");
        
        //implemente o que esta faltando

        //iniciarProcessamento();
        
        //iniciarCarregamento();
        
        //iniciarLeituraDeDados();
        
        System.out.println("Inicialização do computador completada");
    }

}
