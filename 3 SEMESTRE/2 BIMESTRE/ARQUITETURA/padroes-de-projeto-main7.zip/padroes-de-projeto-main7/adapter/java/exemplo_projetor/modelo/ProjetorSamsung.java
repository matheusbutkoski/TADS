package adapter.java.exemplo_projetor.modelo;

public class ProjetorSamsung {

    public void turnOn() { 
        System.out.println("Ligando projetor da Samsung");
      }
    
}
