package proxy.java.exemplo_imagem.modelo;

public interface Imagem{
    
    void exibir();

}
