package factory_method.java.exemplo_transportes.antes_do_padrao.modelo;

public class Ferroviario extends Transporte {

    public void entregar() { 
    
        System.out.println("Entrega com transporte Ferroviário");

    }     
}
