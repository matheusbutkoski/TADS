package adapter.java.atividade_pagamento_cartao.modelo;

public class MaquinaStone {
    
    public void registrar(Double valor) {
        System.out.println("Cartão registrado com Stone no valor de " + valor);
    }

}
