package facade.java.atividade_computador.modelo;

public class Memoria {

    public void iniciarCarregamento(){
        System.out.println("Iniciando carregamento para memória...");
    }
    
}
