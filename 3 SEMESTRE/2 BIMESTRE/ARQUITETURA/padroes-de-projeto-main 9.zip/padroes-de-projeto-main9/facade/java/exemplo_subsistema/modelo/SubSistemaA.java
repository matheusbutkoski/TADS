package facade.java.exemplo_subsistema.modelo;

public class SubSistemaA {
 
    public void operacaoA()
    {
        System.out.println("Operacao A");
    }

}
