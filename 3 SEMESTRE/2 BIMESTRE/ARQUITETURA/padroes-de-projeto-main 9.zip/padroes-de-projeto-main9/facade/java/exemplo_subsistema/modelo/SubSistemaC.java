package facade.java.exemplo_subsistema.modelo;

public class SubSistemaC {

    public void operacaoC()
    {
        System.out.println("Operacao C");
    }
    
}
