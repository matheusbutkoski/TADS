package decorator.java.exemplo_arma.modelo;

public class ArmaBase implements Arma {

    
    @Override
    public void montar() {
        System.out.println("Essa é uma arma base");
      }
    
}
