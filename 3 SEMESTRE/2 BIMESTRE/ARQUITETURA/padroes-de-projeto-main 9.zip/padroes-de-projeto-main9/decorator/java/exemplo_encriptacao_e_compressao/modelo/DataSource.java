package decorator.java.exemplo_encriptacao_e_compressao.modelo;

public interface DataSource {

    void writeData(String data);

    String readData();

    
}
