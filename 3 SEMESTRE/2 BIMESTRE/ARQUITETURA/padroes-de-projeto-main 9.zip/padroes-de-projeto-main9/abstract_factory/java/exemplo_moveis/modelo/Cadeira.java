package abstract_factory.java.exemplo_moveis.modelo;

public interface Cadeira {

    public void sentar();
    
}
