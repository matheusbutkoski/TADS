package abstract_factory.java.exemplo_moveis.modelo;

public interface Sofa {

    public void deitar();

}
