package builder.java.atividade_casa.componentes;


public class Janela {

    //"Preciso que você implemente o meu código";

}