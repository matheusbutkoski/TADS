package chain_of_responsibility.java.atividade_desconto.modelo;

public class ProcessadorSupervisor {

    //implemnte
    
}
