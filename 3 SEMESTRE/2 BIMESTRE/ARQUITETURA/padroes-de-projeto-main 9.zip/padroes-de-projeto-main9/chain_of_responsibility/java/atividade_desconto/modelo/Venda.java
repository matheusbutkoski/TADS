package chain_of_responsibility.java.atividade_desconto.modelo;

public class Venda {

    //Classe deve ter no mínimo dois atributos.  
    
}
