package chain_of_responsibility.java.atividade_desconto;

public class Cliente {
    
     //implemente os teste, no mínimo 1 para cada caso. 
         

}