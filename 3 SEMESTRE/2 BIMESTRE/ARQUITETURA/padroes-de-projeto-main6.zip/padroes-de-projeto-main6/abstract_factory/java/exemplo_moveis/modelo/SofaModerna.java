package abstract_factory.java.exemplo_moveis.modelo;

public class SofaModerna implements Sofa {
    public void deitar(){
        System.out.println("Deitando em um sofa moderno");
    }
}
