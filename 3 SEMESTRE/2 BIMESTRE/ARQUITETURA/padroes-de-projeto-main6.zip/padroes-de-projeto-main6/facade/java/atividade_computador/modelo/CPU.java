package facade.java.atividade_computador.modelo;

public class CPU {
    
    public void iniciarProcessamento(){
        System.out.println("Inciando processamento...");
    }
}
