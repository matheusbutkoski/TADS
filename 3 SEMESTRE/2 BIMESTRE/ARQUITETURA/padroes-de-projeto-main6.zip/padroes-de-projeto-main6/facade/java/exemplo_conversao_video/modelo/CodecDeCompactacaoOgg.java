package facade.java.exemplo_conversao_video.modelo;

public class CodecDeCompactacaoOgg implements Codec {

    public String tipo = "ogg";

}