package facade.java.exemplo_subsistema.modelo;

public class SubSistemaB {
 
    public void operacaoB()
    {
        System.out.println("Operacao B");
    }

}
