package factory_method.java.exemplo_transportes.half_simple.modelo;

public class Ferroviario extends Transporte {

    public void entregar() { 
    
        System.out.println("Entrega com transporte Ferroviário");

    }     
}
