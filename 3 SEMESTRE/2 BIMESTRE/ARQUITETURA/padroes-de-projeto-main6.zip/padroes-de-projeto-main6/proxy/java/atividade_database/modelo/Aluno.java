package proxy.java.atividade_database.modelo;

public interface Aluno {
    
    public String getId();
    public String getNome();
    
}
