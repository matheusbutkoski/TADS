package strategy.java.atividade_estrategia_de_ordenacao.strategy;

public abstract class OrdenacaoStrategy {

    public abstract void ordenar(int[] elementos);
    
}
