package adapter;

public class ControleMaquinas {
    public void iniciar(MaquinaCartao maquina){
        maquina.compra();
    }
}
