package adapter;

public interface MaquinaCartao {
    public void compra();
}
