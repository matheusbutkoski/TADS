package adapter;

public class MaquinaStone {
    
    public void registrar(Double valor) {
        System.out.println("Cartão registrado com Stone no valor de " + valor);
    }
}
