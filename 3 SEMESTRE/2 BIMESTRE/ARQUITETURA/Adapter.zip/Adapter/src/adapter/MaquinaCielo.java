package adapter;

public class MaquinaCielo {
    
    public void processar(Double valor) {
        System.out.println("Cartão processado com Cielo o valor de " + valor);
    }
}
