package abstract_factory.java.exemplo_moveis.modelo;

public interface MesaDeCentro {

    public void colocarDecoracao();

}
