package abstract_factory.java.exemplo_moveis.modelo;

public class CadeiraVitoriano implements Cadeira {

    public void sentar() {
        System.out.println("Sentado em uma cadeira vitoriana");
    }
  
}
