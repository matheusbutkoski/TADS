package builder.java.atividade_casa.diretor;

import builder.java.exemplo_carro.builders.Builder;

public class Diretor {

    public void implemete(Builder builder) {
    
        System.out.println("Preciso que você implemente o meu código");

    }
        


}

