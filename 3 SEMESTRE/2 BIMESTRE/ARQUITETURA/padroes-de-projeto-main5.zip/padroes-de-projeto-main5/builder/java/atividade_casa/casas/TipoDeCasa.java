package builder.java.atividade_casa.casas;

public enum TipoDeCasa {
    Y, X, Z // tipos de casas que você vai construir.
}
