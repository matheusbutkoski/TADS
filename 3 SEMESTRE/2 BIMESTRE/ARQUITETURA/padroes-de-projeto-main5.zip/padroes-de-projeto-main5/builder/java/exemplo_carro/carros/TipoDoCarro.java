package builder.java.exemplo_carro.carros;

public enum TipoDoCarro {
    CARRO_CIDADE, CARRO_SPORT, SUV
}
