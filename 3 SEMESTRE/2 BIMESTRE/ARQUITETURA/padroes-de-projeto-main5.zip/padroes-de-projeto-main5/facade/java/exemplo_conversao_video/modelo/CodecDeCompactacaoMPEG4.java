package facade.java.exemplo_conversao_video.modelo;

public class CodecDeCompactacaoMPEG4 implements Codec {
    public String type = "mp4";

}