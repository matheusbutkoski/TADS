package adapter.java.atividade_pagamento_cartao;


public class Cliente {

    public static void main(String[] args) {
    
        System.out.println("Teste sua implementação");
    }

}
