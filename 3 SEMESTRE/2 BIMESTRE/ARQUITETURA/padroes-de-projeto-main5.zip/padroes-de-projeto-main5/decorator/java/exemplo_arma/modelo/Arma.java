package decorator.java.exemplo_arma.modelo;

public interface Arma {
    
    public void montar();

}
