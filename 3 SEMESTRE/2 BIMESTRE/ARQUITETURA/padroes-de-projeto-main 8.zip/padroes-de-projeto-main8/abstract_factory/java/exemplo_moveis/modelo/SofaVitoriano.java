package abstract_factory.java.exemplo_moveis.modelo;

public class SofaVitoriano implements Sofa{
    public void deitar(){
        System.out.println("Deitando em um sofa vitoriano");
    }
}
