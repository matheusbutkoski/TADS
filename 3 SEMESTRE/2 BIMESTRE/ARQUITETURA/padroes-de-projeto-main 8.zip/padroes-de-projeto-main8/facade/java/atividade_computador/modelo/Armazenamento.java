package facade.java.atividade_computador.modelo;

public class Armazenamento {

    public void iniciarLeituraDeDados(){
        System.out.println("Iniciando leitura de dados do dispositivo de armazenamento...");
    }
    
}
