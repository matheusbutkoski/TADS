package facade.java.exemplo_conversao_video.modelo;

public interface Codec {
    
}
