package observer.java.atividade_canal.modelo;

public class Conteudo {

    // implemente
    
}
