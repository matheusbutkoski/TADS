
/**
* Pessoas são sujeitos (isto é, objetos que podem ser observados)
*/


package observer.java.atividade_canal.modelo;

public class Pessoa {
    
    // implemente

}
