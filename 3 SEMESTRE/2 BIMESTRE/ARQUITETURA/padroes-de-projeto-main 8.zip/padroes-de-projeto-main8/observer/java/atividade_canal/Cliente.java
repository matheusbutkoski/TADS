package observer.java.atividade_canal;

public class Cliente {
    
     //implemente
         

}