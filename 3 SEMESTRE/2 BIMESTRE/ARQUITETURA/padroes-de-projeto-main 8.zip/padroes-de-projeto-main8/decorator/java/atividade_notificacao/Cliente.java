package decorator.java.atividade_notificacao;

public class Cliente {

    public static void main(String[] args) {

       System.out.println("### Teste seu desafio do Decorator ###");

    }
    
}
