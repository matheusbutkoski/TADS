package decorator.java.atividade_notificacao.modelo;

public class NotificacaoBase {

    //implemente seu código
        
}
