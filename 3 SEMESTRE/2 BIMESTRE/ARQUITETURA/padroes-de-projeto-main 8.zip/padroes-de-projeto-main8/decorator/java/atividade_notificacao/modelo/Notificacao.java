package decorator.java.atividade_notificacao.modelo;

public interface Notificacao {

    //implemente seu código
    
}
