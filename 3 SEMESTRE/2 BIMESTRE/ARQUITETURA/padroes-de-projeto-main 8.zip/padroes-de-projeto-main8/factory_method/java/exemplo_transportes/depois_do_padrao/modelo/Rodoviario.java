package factory_method.java.exemplo_transportes.depois_do_padrao.modelo;

public class Rodoviario extends Transporte {

    public void entregar() { 
        
        System.out.println("Entrega com transporte Rodoviário");
    
    }  
}
