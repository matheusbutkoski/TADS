package factory_method.java.exemplo_transportes.half_simple.modelo;

public abstract class Transporte {
    
    
    public static final int GRANDE = 1;
    public static final int POUCA = 2;
    
    public abstract void entregar();

      
}
