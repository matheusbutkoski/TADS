package adapter.java.exemplo_projetor.adapters;

public interface Projetor {
    public void liga();
}
