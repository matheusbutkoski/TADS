
package adapter.java.exemplo_burraco_redondo.modelo;

public class PinoRedondo {
    
    private double raio;

    public PinoRedondo() {}

    public PinoRedondo(double raio) {
        this.raio = raio;
    }

    public double getRaio() {
        return raio;
    }
}