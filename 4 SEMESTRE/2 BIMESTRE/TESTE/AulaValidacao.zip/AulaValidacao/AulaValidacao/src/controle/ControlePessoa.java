package controle;

import modelo.Pessoa;
import persistencia.DaoPessoa;
import util.Input;


public class ControlePessoa {
    private DaoPessoa dao;

    public ControlePessoa() {
        dao = new DaoPessoa();
    }
    
    
    public void cadastrar(){
        Pessoa p = new Pessoa();
        
        
    }
    
    public void setarDados(Pessoa p){
        
        System.out.println("informe o nome: ");
        p.setNome(Input.nextLine());
        System.out.println("informe o CPF: ");
        p.setCpf(Input.next());
        System.out.println("informe o email: ");
        p.setEmail(Input.next());
        System.out.println("informe o telefone: ");
        p.setTelefone(Input.next());
    }
    
}
