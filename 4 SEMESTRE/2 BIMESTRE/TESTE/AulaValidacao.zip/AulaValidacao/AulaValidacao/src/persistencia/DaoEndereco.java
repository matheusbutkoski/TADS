package persistencia;

import modelo.Endereco;


public class DaoEndereco extends DAO{

    public DaoEndereco() {
        super(Endereco.class);
    }
    
}
