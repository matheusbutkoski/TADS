package persistencia;

import modelo.Pessoa;


public class DaoPessoa extends DAO{
    
    public DaoPessoa() {
        super(Pessoa.class);
    }
    
}
