package principal;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import modelo.Pessoa;
import persistencia.ConexaoBD;

/**
 *
 * @author ANDRE.LUCHESI
 */
public class AulaValidacao {

    
    public static void main(String[] args) {
        // TODO code application logic here
        ConexaoBD.getConection();
        
        Pessoa p = new Pessoa();
        p.setNome("André conceição ãêí");
        p.setCpf("123456789-10");
        p.setTelefone("(045) 99999-9999");
        p.setEmail(null);
        
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Pessoa>> violations = validator.validate(p);
        
        for (ConstraintViolation<Pessoa> violation : violations) {
            System.out.println(violation.getMessage());
        }
    }
    
}
