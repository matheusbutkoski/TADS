package modelo;

import java.io.Serializable;

public abstract class Entidade implements Serializable{
    public abstract Integer getId();
}
