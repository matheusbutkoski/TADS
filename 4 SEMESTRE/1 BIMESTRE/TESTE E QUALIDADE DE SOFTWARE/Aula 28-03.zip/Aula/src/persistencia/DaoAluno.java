package persistencia;

import modelo.Aluno;

public class DaoAluno extends DAO{

    public DaoAluno() {
        super(Aluno.class);
    }
    
    
}
