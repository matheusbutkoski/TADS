package modelo;

/**
 *
 * @author ANDRE.LUCHESI
 */
public abstract class Entidade {
    
    public abstract Integer getId();
}
