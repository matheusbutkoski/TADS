package persistencia;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author ANDRE.LUCHESI
 */
public class ConexaoBD {
    private static EntityManagerFactory emFactoryObj;
    private static final String PERSISTENCE_UNIT_NAME = "AulaPU";  
 
    public static EntityManagerFactory getConnection()  {
        emFactoryObj = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        return emFactoryObj;
    }

}
