package principal;

import modelo.Aluno;
import persistencia.ConexaoBD;


public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ConexaoBD.getConnection();
        
        Aluno al = new Aluno();
        al.setNome("Andre");
        al.setRa("10");
        
        ConexaoBD.getConnection().createEntityManager().persist(al);
        ConexaoBD.getConnection().close();
    }
    
}
