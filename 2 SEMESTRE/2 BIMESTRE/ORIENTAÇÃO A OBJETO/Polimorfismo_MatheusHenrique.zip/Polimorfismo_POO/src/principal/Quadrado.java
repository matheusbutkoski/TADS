/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

/**
 *
 * @author Andre
 */
public class Quadrado extends Quadrilatero{

    public Quadrado() {
        super.formaGeometricaNome = "Quadrado";
    }
    
    public Quadrado(double lado) {
        super.formaGeometricaNome = "Quadrado";
        super.alturaLadoDireito = lado;
        super.alturaLadoEsquerdo = lado;
        super.baseInferior = lado;
        super.baseSuperior = lado;
    }
    
    public double getLado(){
        return super.alturaLadoDireito;
    }
    
    public void setLado(double lado){
        super.alturaLadoDireito = lado;
        super.alturaLadoEsquerdo = lado;
        super.baseInferior = lado;
        super.baseSuperior = lado;
    }

    @Override
    public void calacularPerimetro() {
        double perimetro =  Math.pow(super.alturaLadoDireito, 2);
        System.out.format("O Quadrado possui perímetro de: %.2f metros!\n", perimetro);
    }
    
    
}
