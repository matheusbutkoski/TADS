package principal;


public class Trapezio  extends Quadrilatero{

    public Trapezio() {
        super.formaGeometricaNome = "Trapézio";
    }
    
    public Trapezio(double baseInferior, double baseSuperior, double altura) {
        super.formaGeometricaNome = "Trapézio";
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
        super.baseInferior = baseInferior;
        super.baseSuperior = baseSuperior;
    }
    
    public double getBaseInferior(){
        return super.baseInferior;
    }
    
    public void setBaseInferior(double base){
        super.baseInferior = base;
    }
    
    public double getBaseSuperior(){
        return super.baseSuperior;
    }
    
    public void setBaseSuperior(double base){
        super.baseSuperior = base;
    }
    
    public double getAltura(){
        return super.alturaLadoDireito;
    }
    
    public void setAltura(double altura){
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
    }

    @Override
    public void calacularPerimetro() {
        double perimetro = (baseInferior + baseSuperior)/2 * alturaLadoDireito;
        System.out.format("O Trapézio possui perímetro de: %.2f metros!\n", perimetro);
    }
    
    
}
