package principal;


public class FormaGeometrica {
 protected String formaGeometricaNome;
 protected double raio;
 protected double l1;
 protected double l2;
 protected double l3;
        
 
 public FormaGeometrica(){
     
 }
 

    public void calacularPerimetro() {
        double perimetro = l1 + l2 + l3;
        System.out.format("O Triângulo possui perímetro de: %.2f metros!\n", perimetro);
    }
    
    public String getFormaGeometricaNome() {
        return formaGeometricaNome;
    }
 
}
