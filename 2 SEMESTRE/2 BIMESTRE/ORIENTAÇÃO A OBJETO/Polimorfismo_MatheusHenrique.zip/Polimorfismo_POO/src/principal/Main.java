package principal;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        ArrayList<Quadrilatero> lista = new ArrayList<>();
        ArrayList<FormaGeometrica> lista2 = new ArrayList<>();
        int op;

        do {
            System.out.println("\nDigite 1 para adicionar um Quadrado");
            System.out.println("Digite 2 para adicionar um Retângulo");
            System.out.println("Digite 3 para adicionar um Trapézio");
            System.out.println("Digite 4 para adicionar um Losango");
            System.out.println("Digite 5 para adicionar um Triangulo");
            System.out.println("Digite 6 para adicionar um Circulo");
            System.out.println("Digite 7 Exibir perímetro de todos os objetos Quadriláteros");
            System.out.println("Digite 8 Exibir perímetro de todas as Formas Geometricas");
            System.out.println("Digite 0 para sair!");
            op = teclado.nextInt();

            switch (op) {
                case 1:
                    Quadrado quadrado = gerarQuadrado();
                    lista.add(quadrado);
                    break;
                case 2:
                    Retangulo retangulo = gerarRetangulo();
                    lista.add(retangulo);
                    break;
                case 3:
                    Trapezio trapezio = gerarTrapezio();
                    lista.add(trapezio);
                    break;
                case 4:
                    Losango losango = gerarLosango();
                    lista.add(losango);
                    break;
                case 5:
                    Triangulo triangulo = gerarTriangulo();
                    lista2.add(triangulo);
                    break;
                case 6:
                    Circulo circulo = gerarCirculo();
                    lista2.add(circulo);
                case 7:
                    exibir(lista);
                    break;
                case 8:
                    exibir2(lista2);
                    break;
                default:
                    if (op > 0) {
                        System.out.println("\nOpção inválida!");
                    }
            }
        } while (op != 0);
    }

    public static Quadrado gerarQuadrado() {
        System.out.println("\nInforme a medida do lado do Quadrado:");
        double lado = teclado.nextDouble();
        Quadrado quadrado = new Quadrado(lado);
        return quadrado;
    }

    public static Retangulo gerarRetangulo() {
        System.out.println("\nInforme a base e altura do Retângulo:");
        double base = teclado.nextDouble();
        double altura = teclado.nextDouble();
        Retangulo retangulo = new Retangulo(base, altura);
        return retangulo;
    }

    public static Trapezio gerarTrapezio() {
        System.out.println("\nInforme a base inferior, base superior e altura do Trapézio:");
        double baseInferior = teclado.nextDouble();
        double baseSuperior = teclado.nextDouble();
        double altura = teclado.nextDouble();
        Trapezio trapezio = new Trapezio(baseInferior, baseSuperior, altura);
        return trapezio;
    }

    public static Losango gerarLosango() {
        System.out.println("\nInforme a base e altura do Losango:");
        double base = teclado.nextDouble();
        double altura = teclado.nextDouble();
        Losango losango = new Losango(base, altura);
        return losango;
    }
    
    public static Triangulo gerarTriangulo(){
        System.out.println("Informe os 3 lados do triangulo");
        double l1 = teclado.nextDouble();
        double l2 = teclado.nextDouble();
        double l3 = teclado.nextDouble();
        Triangulo triangulo = new Triangulo(l1, l2, l3);
        return triangulo;    
    }
    
    public static Circulo gerarCirculo(){
        System.out.println("Informe o raio do circulo");
        double r = teclado.nextDouble();
        Circulo circulo = new Circulo(r);
        return circulo;    
    }

    public static void exibir(ArrayList<Quadrilatero> listaQuadrilateros) {
        System.out.println("\nExibindo Perímetro de todos os objetos Quadriláteros");
        for (int i = 0; i < listaQuadrilateros.size(); i++) {
            System.out.println("\nQuadrilátero: " + (i+1));
            System.out.println("Forma geométrica: " + listaQuadrilateros.get(i).getFormaGeometricaNome());
            listaQuadrilateros.get(i).calacularPerimetro();
        }
    }
    
    public static void exibir2(ArrayList<FormaGeometrica> listaFormaGeometrica) {
        System.out.println("\nExibindo Perímetro de todos as Formas Geometricas");
        for (int i = 0; i < listaFormaGeometrica.size(); i++) {
            System.out.println("\nFormaGeometrica: " + (i+1));
            System.out.println("Forma geométrica: " + listaFormaGeometrica.get(i).getFormaGeometricaNome());
           listaFormaGeometrica.get(i).calacularPerimetro();
        }
    }

}
