/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

/**
 *
 * @author Andre
 */
public class Retangulo extends Quadrilatero{

    public Retangulo() {
        super.formaGeometricaNome = "Retângulo";
    }
    
    public Retangulo(double base, double altura) {
        super.formaGeometricaNome = "Retângulo";
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
        super.baseInferior = base;
        super.baseSuperior = base;
    }
    
    public double getBase(){
        return super.baseInferior;
    }
    
    public void setBase(double base){
        super.baseInferior = base;
        super.baseSuperior = base;
    }
    
    public double getAltura(){
        return super.alturaLadoDireito;
    }
    
    public void setAltura(double altura){
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
    }

    @Override
    public void calacularPerimetro() {
        double perimetro =  super.baseInferior * super.alturaLadoDireito;
        System.out.format("O Retângulo possui perímetro de: %.2f metros!\n", perimetro);
    }
    
    
    
}
