package principal;


public class Losango extends Quadrilatero{

    public Losango() {
        super.formaGeometricaNome = "Losango";
    }
    
    public Losango(double base, double altura) {
        super.formaGeometricaNome = "Losango";
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
        super.baseInferior = base;
        super.baseSuperior = base;
    }
    
    public double getBase(){
        return super.baseInferior;
    }
    
    public void setBase(double base){
        super.baseInferior = base;
        super.baseSuperior = base;
    }
    
    public double getAltura(){
        return super.alturaLadoDireito;
    }
    
    public void setAltura(double altura){
        super.alturaLadoDireito = altura;
        super.alturaLadoEsquerdo = altura;
    }

    @Override
    public void calacularPerimetro() {
        double perimetro =  super.baseInferior * super.alturaLadoDireito;
        System.out.format("O Losango possui perímetro de: %.2f metros!\n", perimetro);
    }
}
