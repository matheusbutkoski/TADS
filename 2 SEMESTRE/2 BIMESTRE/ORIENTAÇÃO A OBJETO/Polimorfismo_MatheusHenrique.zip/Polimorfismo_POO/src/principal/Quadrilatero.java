package principal;

public class Quadrilatero {
    
    protected String formaGeometricaNome = "Quadrilátero";
    protected double baseSuperior;
    protected double baseInferior;
    protected double alturaLadoEsquerdo;
    protected double alturaLadoDireito;

    public Quadrilatero() {
    }

    public Quadrilatero(double baseSuperior, double baseInferior, double alturaLadoEsquerdo, double alturaLadoDireito) {
        this.baseSuperior = baseSuperior;
        this.baseInferior = baseInferior;
        this.alturaLadoEsquerdo = alturaLadoEsquerdo;
        this.alturaLadoDireito = alturaLadoDireito;
    }

    public String getFormaGeometricaNome() {
        return formaGeometricaNome;
    }
    
    public void calacularPerimetro(){
        double perimetro = (baseInferior + baseSuperior)/2 + (alturaLadoEsquerdo + alturaLadoDireito)/2;
        System.out.format("O Quadrilátero possui perímetro de: %.2f metros!\n", perimetro);
    }
    
    
}
