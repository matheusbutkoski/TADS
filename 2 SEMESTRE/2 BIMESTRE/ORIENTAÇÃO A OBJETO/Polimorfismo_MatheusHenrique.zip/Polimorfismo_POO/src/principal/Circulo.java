package principal;

public class Circulo extends FormaGeometrica{
    
     public Circulo() {
        super.formaGeometricaNome = "Círculo";
    }
    
    
    public Circulo(double r){
        super.formaGeometricaNome = "Círculo";
        super.raio = r;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }
    
    public void getRaio(double raio) {
        this.raio = raio;
    }
    
          
     @Override
    public void calacularPerimetro(){
        double perimetro =  2 * 3.14f * raio;
        System.out.format("O Círculo possui perímetro de: %.2f metros!\n", perimetro);
    }
    
}
