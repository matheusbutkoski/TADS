package principal;
public class Triangulo extends FormaGeometrica {
    
    public Triangulo(){
        super.formaGeometricaNome = "Triangulo";
    }
    
    public Triangulo(double lado1, double lado2, double lado3){
        super.formaGeometricaNome = "Triangulo";
        super.l1 = lado1;
        super.l2 = lado2;
        super.l3 = lado3;
    }
    
    
      @Override
    public void calacularPerimetro() {
        double perimetro = l1 + l2 + l3;
        System.out.format("O Triângulo possui perímetro de: %.2f metros!\n", perimetro);
    }
}
